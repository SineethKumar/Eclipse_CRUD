package sineeth.manda.web;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import sineeth.manda.web.dao.UserDao;
import sineeth.manda.web.model.User;

/**
 * Servlet implementation class profile
 */
public class profile extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session=request.getSession();
		String uname=(String)session.getAttribute("username");
		UserDao dao=new UserDao();
		User u=null;
		try {
			u = dao.ProfileShow(uname);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		request.setAttribute("user",u);
		RequestDispatcher rd=request.getRequestDispatcher("Confirm.jsp");
		rd.forward(request,response);
	}


}
