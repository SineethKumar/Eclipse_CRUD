package sineeth.manda.web;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import sineeth.manda.web.dao.UserDao;

/**
 * Servlet implementation class DeleteUserDemo
 */
public class DeleteUserDemo extends HttpServlet
{	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		// TODO Auto-generated method stub
		String r=request.getParameter("droll");
		UserDao dao=new UserDao();
		int row=0;
		try {
			row = dao.DeleteUser(r);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		HttpSession session=request.getSession();
		if(row==1 && r.equals(session.getAttribute("roll")))
		{
			session.removeAttribute("username");
			session.removeAttribute("roll");
			session.removeAttribute("question");
			session.removeAttribute("str");
			session.invalidate();
			response.sendRedirect("index.jsp");
		}
		else
		{
			request.setAttribute("drows",row);
			String s="delete";
			request.setAttribute("string",s);
			RequestDispatcher rd=request.getRequestDispatcher("showuser.jsp");
			rd.forward(request,response);
		}
	}

}
