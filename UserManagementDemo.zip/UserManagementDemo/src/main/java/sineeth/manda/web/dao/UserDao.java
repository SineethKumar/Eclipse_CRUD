package sineeth.manda.web.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import sineeth.manda.web.model.User;

public class UserDao {
	
	public ArrayList<User> getUsers() throws ClassNotFoundException, SQLException {
		ArrayList<User> ul = new ArrayList<User>();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/school", "root", "Sineeth@123");
			Statement st=con.createStatement();
			ResultSet rs = st.executeQuery("select * from usermanagement3");
			while(rs.next())
			{
				User u=new User();
				u.setRoll(rs.getString("sroll"));
				u.setName(rs.getString("sname"));
				u.setPhoneno(rs.getString("phoneno"));
				u.setEmail(rs.getString("mail_Id"));
				ul.add(u);
			}
			
		} catch (Exception e) {
			System.out.println("ayyooooooooo");
		}
		return ul;
	}
	public int userInsert(String roll,String name,String phno,String mail,String uname,String pass,String sec,String ans) throws ClassNotFoundException, SQLException {
		int c=0;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/school","root","Sineeth@123");
			PreparedStatement st = con.prepareStatement("insert into usermanagement3 values (?,?,?,?,?,?,?,?)");
			st.setString(1,roll);
			st.setString(2,name);
			st.setString(3,phno);
			st.setString(4,mail);
			st.setString(5,uname);
			st.setString(6,pass);
			st.setString(7,sec);
			st.setString(8,ans);
			c = st.executeUpdate();
			
		} catch (Exception e) {
			System.out.println("ayyooooooooo");
		}
		return c;
	}
	public int UpdateUser(String croll,String nroll,String name,String phno,String mail,String sec,String ans) throws ClassNotFoundException, SQLException {
		int c=0;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/school", "root","Sineeth@123");
			PreparedStatement st = con.prepareStatement("update usermanagement3 set sroll=?,sname=?,phoneno=?,mail_Id=?,Sec_que=?,Sec_ans=?where sroll=?");
			st.setString(1,nroll);
			st.setString(2,name);
			st.setString(3,phno);
			st.setString(4,mail);
			//st.setString(5,uname);
			//st.setString(6,pass);
			st.setString(5,sec);
			st.setString(6,ans);
			st.setString(7,croll);
			c = st.executeUpdate();
			
		} catch (Exception e) {
			System.out.println("ayyooooooooo");
		}
		return c;
	}
	public int DeleteUser(String roll) throws ClassNotFoundException, SQLException {
		int c=0;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/school","root","Sineeth@123");
			PreparedStatement st = con.prepareStatement("delete from usermanagement3 where sroll=?");
			st.setString(1,roll);
			c=st.executeUpdate();
		} catch (Exception e) {
			System.out.println("ayyooooooooo");
		}
		return c;
	}
	public User SearchUser(String roll) throws ClassNotFoundException, SQLException {
		User u=new User();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/school","root","Sineeth@123");
			PreparedStatement st = con.prepareStatement("select * from usermanagement3 where sroll=?");
			st.setString(1,roll);
			ResultSet rs=st.executeQuery();
			rs.next();
			u.setRoll(rs.getString("sroll"));
			u.setName(rs.getString("sname"));
			u.setPhoneno(rs.getString("phoneno"));
			u.setEmail(rs.getString("mail_Id"));
			u.setUsername(rs.getString("Username"));
			u.setPassword(rs.getString("Password"));
			u.setAnswer(rs.getString("Sec_ans"));
			
		} catch (Exception e) {
			System.out.println("ayyooooooooo");
		}
		return u;
	}
	public User ProfileShow(String uname) throws ClassNotFoundException, SQLException {
		User u=new User();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/school","root","Sineeth@123");
			PreparedStatement st = con.prepareStatement("select * from usermanagement3 where Username=?");
			st.setString(1,uname);
			ResultSet rs=st.executeQuery();
			rs.next();
			u.setRoll(rs.getString("sroll"));
			u.setName(rs.getString("sname"));
			u.setPhoneno(rs.getString("phoneno"));
			u.setEmail(rs.getString("mail_Id"));
			u.setUsername(rs.getString("Username"));
			u.setPassword(rs.getString("Password"));
			
		} catch (Exception e) {
			System.out.println("ayyooooooooo");
		}
		return u;
	}
	public User Duplicateroll(String roll) throws ClassNotFoundException, SQLException {
		User u=new User();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/school","root","Sineeth@123");
			PreparedStatement st = con.prepareStatement("select * from usermanagement3 where sroll=?");
			st.setString(1,roll);
			ResultSet rs=st.executeQuery();
			rs.next();
			u.setRoll(rs.getString("sroll"));
			u.setName(rs.getString("sname"));
			u.setPhoneno(rs.getString("phoneno"));
			u.setEmail(rs.getString("mail_Id"));
		} catch (Exception e) {
			System.out.println("ayyooooooooo");
		}
		return u;
	}
	public User userLogin(String uname,String pass) throws ClassNotFoundException, SQLException {
		User u=new User();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/school","root","Sineeth@123");
			PreparedStatement st = con.prepareStatement("select * from usermanagement3 where Username=? and Password=?");
			st.setString(1,uname);
			st.setString(2,pass);
			ResultSet rs=st.executeQuery();
			rs.next();
			u.setRoll(rs.getString("sroll"));
			u.setName(rs.getString("sname"));
			u.setPhoneno(rs.getString("phoneno"));
			u.setEmail(rs.getString("mail_Id"));
			u.setUsername(rs.getString("Username"));
			u.setPassword(rs.getString("Password"));
			u.setQuestion(rs.getString("Sec_que"));
			u.setAnswer(rs.getString("Sec_ans"));
		} catch (Exception e) {
			System.out.println("ayyooooooooo");
		}
		return u;
	}
	public User Duplicateuname(String uname) throws ClassNotFoundException, SQLException {
		User u=new User();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/school","root","Sineeth@123");
			PreparedStatement st = con.prepareStatement("select * from usermanagement3 where Username=?");
			st.setString(1,uname);
			ResultSet rs=st.executeQuery();
			rs.next();
			u.setRoll(rs.getString("sroll"));
			u.setName(rs.getString("sname"));
			u.setPhoneno(rs.getString("phoneno"));
			u.setEmail(rs.getString("mail_Id"));
		} catch (Exception e) {
			System.out.println("ayyooooooooo");
		}
		return u;
	}
	public User Duplicatemail(String mail) throws ClassNotFoundException, SQLException {
		User u=new User();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/school","root","Sineeth@123");
			PreparedStatement st = con.prepareStatement("select * from usermanagement3 where mail_Id=?");
			st.setString(1,mail);
			ResultSet rs=st.executeQuery();
			rs.next();
			u.setRoll(rs.getString("sroll"));
			u.setName(rs.getString("sname"));
			u.setPhoneno(rs.getString("phoneno"));
			u.setEmail(rs.getString("mail_Id"));
		} catch (Exception e) {
			System.out.println("ayyooooooooo");
		}
		return u;
	}
	
}
