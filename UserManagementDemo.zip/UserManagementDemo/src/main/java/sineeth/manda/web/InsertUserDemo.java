package sineeth.manda.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import sineeth.manda.web.dao.UserDao;
import sineeth.manda.web.model.User;

/**
 * Servlet implementation class InsertUserDemo
 */
public class InsertUserDemo extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String r=request.getParameter("roll");
		String n=request.getParameter("name");
		String p=request.getParameter("phno");
		String m=request.getParameter("mail");
		String u=request.getParameter("uname");
		String pass=request.getParameter("pass");
		String cpass=request.getParameter("cpass");
		String sec=request.getParameter("question");
		String ans=request.getParameter("qanswer");
		HttpSession session=request.getSession();
		session.setAttribute("check","nr");
		if(pass.equals(cpass))
		{
			UserDao dao=new UserDao();
			User u0=null;
			try {
				u0 = dao.Duplicateroll(r);
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(u0.getRoll()==null)
			{
				User u1=null;
				try {
					u1 = dao.Duplicateuname(u);
				} catch (ClassNotFoundException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if(u1.getRoll()==null)
				{
					User u2=null;
					try {
						u2 = dao.Duplicatemail(m);
					} catch (ClassNotFoundException | SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					if(u2.getRoll()==null)
					{
						int row=0;
						try {
							row = dao.userInsert(r,n,p,m,u,pass,sec,ans);
						} catch (ClassNotFoundException | SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						
						if(row==1)
						{
							session.setAttribute("username",u);
							session.setAttribute("roll",r);
							session.setAttribute("question",sec);
							session.setAttribute("str","right");
						}
						request.setAttribute("irow",row);
						String s="insert";
						request.setAttribute("string",s);
						RequestDispatcher rd=request.getRequestDispatcher("showuser.jsp");
						rd.forward(request,response);
					}
					else
					{
						String msg="mail";
						request.setAttribute("msg",msg); 
						request.setAttribute("roll",r);
						request.setAttribute("name",n);
						request.setAttribute("phno",p);
						request.setAttribute("mail",m);
						request.setAttribute("uname",u);
						request.setAttribute("pass",pass);
						request.setAttribute("cpass",cpass);
						RequestDispatcher rd=request.getRequestDispatcher("Register.jsp");
						rd.forward(request,response);
					}
				}
				else
				{
					String msg="uname";
					request.setAttribute("msg",msg); 
					request.setAttribute("roll",r);
					request.setAttribute("name",n);
					request.setAttribute("phno",p);
					request.setAttribute("mail",m);
					request.setAttribute("uname",u);
					request.setAttribute("pass",pass);
					request.setAttribute("cpass",cpass);
					RequestDispatcher rd=request.getRequestDispatcher("Register.jsp");
					rd.forward(request,response);
				}
				
			}
			else
			{
				String msg="roll";
				request.setAttribute("msg",msg); 
				request.setAttribute("roll",r);
				request.setAttribute("name",n);
				request.setAttribute("phno",p);
				request.setAttribute("mail",m);
				request.setAttribute("uname",u);
				request.setAttribute("pass",pass);
				request.setAttribute("cpass",cpass);
				RequestDispatcher rd=request.getRequestDispatcher("Register.jsp");
				rd.forward(request,response);
			}
		}
			
		else
		{
			String msg="pass";
			request.setAttribute("msg",msg); 
			request.setAttribute("roll",r);
			request.setAttribute("name",n);
			request.setAttribute("phno",p);
			request.setAttribute("mail",m);
			request.setAttribute("uname",u);
			request.setAttribute("pass",pass);
			request.setAttribute("cpass",cpass);
			RequestDispatcher rd=request.getRequestDispatcher("Register.jsp");
			rd.forward(request,response);
		}
		
		
	}

}
