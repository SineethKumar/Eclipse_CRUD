package sineeth.manda.web;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import sineeth.manda.web.dao.UserDao;
import sineeth.manda.web.model.User;

/**
 * Servlet implementation class Confirmation
 */
public class Confirmation extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session=request.getSession();
		String roll=(String) session.getAttribute("roll");
		String ans=request.getParameter("answer");
		UserDao dao=new UserDao();
		User u=null;
		try {
			u=dao.SearchUser(roll);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(u.getAnswer().equals(ans))
		{
			request.setAttribute("user",u);
			RequestDispatcher rd=request.getRequestDispatcher("profile.jsp");
			rd.forward(request,response);
		}
		else
		{
			session.setAttribute("str","wrong");
			RequestDispatcher rd=request.getRequestDispatcher("Homepage.jsp");
			rd.forward(request,response);
		}
	}

}
