package sineeth.manda.web;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sineeth.manda.web.dao.UserDao;
import sineeth.manda.web.model.User;

/**
 * Servlet implementation class update
 */
public class update extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String roll=request.getParameter("froll");
		UserDao dao=new UserDao();
		User u1=null;
		try {
			u1 = dao.SearchUser(roll);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(u1.getRoll()!=null)
		{
			request.setAttribute("msg","hi");
			request.setAttribute("croll",u1.getRoll());
			request.setAttribute("name",u1.getName());
			request.setAttribute("phno",u1.getPhoneno());
			request.setAttribute("mail",u1.getEmail());
			//request.setAttribute("uname",u1.getUsername());
			//request.setAttribute("pass",u1.getPassword());
			RequestDispatcher rd=request.getRequestDispatcher("updatehere.jsp");
			rd.forward(request,response);
		}
		else
		{
			request.setAttribute("string","search");
			request.setAttribute("user",u1);
			RequestDispatcher rd=request.getRequestDispatcher("showuser.jsp");
			rd.forward(request,response);
		}
		
	}
}
