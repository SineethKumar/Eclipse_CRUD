package sineeth.manda.web;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import sineeth.manda.web.dao.UserDao;
import sineeth.manda.web.model.User;

/**
 * Servlet implementation class GetLogin
 */
public class GetLogin extends HttpServlet
{
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		String un=request.getParameter("uname");
		String pa=request.getParameter("pass");
		UserDao dao=new UserDao();
		User u=null;
		try {
			u = dao.userLogin(un,pa);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(u.getRoll()==null)
		{
			RequestDispatcher rd=request.getRequestDispatcher("Login.jsp");
			rd.forward(request,response);
		}
		else
		{
			HttpSession session=request.getSession();
			session.setAttribute("username",un);
			session.setAttribute("roll",u.getRoll());
			session.setAttribute("question",u.getQuestion());
			session.setAttribute("str","right");
			RequestDispatcher rd=request.getRequestDispatcher("Homepage.jsp");
			rd.forward(request,response);
		}
	}

}
