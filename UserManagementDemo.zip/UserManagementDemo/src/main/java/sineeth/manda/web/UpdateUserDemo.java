package sineeth.manda.web;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import sineeth.manda.web.dao.UserDao;
import sineeth.manda.web.model.User;

/**
 * Servlet implementation class UpdateUserDemo
 */
public class UpdateUserDemo extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String cr=request.getParameter("croll");
		String nr=request.getParameter("nroll");
		String n=request.getParameter("name");
		String p=request.getParameter("phno");
		String m=request.getParameter("mail");
		//String u=request.getParameter("uname");
		//String pass=request.getParameter("pass");
		String sec=request.getParameter("question");
		String ans=request.getParameter("qanswer");
		HttpSession session=request.getSession();
		UserDao dao=new UserDao();
		if(cr.equals(nr))
		{
			User u2=null;
			try {
				u2 = dao.Duplicatemail(m);
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(u2.getRoll()==null || u2.getRoll().equals(nr))
			{
				int row=0;
				try {
					row = dao.UpdateUser(cr,nr,n,p,m,sec,ans);
				} catch (ClassNotFoundException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				request.setAttribute("urows",row);
				String s="update";
				if(row==1)
				{
					session.setAttribute("question",sec);
					session.setAttribute("answer",ans);
				}
				request.setAttribute("string",s);
				RequestDispatcher rd=request.getRequestDispatcher("showuser.jsp");
				rd.forward(request,response);
			}
			else
			{
				String msg="mail";
				request.setAttribute("msg",msg); 
				request.setAttribute("croll",cr);
				request.setAttribute("nroll",nr);
				request.setAttribute("name",n);
				request.setAttribute("phno",p);
				request.setAttribute("mail",m);
				//request.setAttribute("uname",u);
				//request.setAttribute("pass",pass);
				RequestDispatcher rd=request.getRequestDispatcher("updatehere.jsp");
				rd.forward(request,response);
			}
			
		}
		else
		{
			User u0=null;
			try {
				u0 = dao.Duplicateroll(nr);
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(u0.getRoll()==null)
			{
					User u2=null;
					try {
						u2 = dao.Duplicatemail(m);
					} catch (ClassNotFoundException | SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					if(u2.getRoll()==null)
					{
						int row=0;
						try {
							row = dao.UpdateUser(cr,nr,n,p,m,sec,ans);
						} catch (ClassNotFoundException | SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						request.setAttribute("urows",row);
						String s="update";
						if(row==1)
						{
							session.setAttribute("question",sec);
							session.setAttribute("answer",ans);
						}
						request.setAttribute("string",s);
						RequestDispatcher rd=request.getRequestDispatcher("showuser.jsp");
						rd.forward(request,response);
					}
					else
					{
						String msg="mail";
						request.setAttribute("msg",msg); 
						request.setAttribute("croll",cr);
						request.setAttribute("nroll",nr);
						request.setAttribute("name",n);
						request.setAttribute("phno",p);
						request.setAttribute("mail",m);
						//request.setAttribute("uname",u);
						//request.setAttribute("pass",pass);
						RequestDispatcher rd=request.getRequestDispatcher("updatehere.jsp");
						rd.forward(request,response);
					}
			}
			else
			{
				String msg="roll";
				request.setAttribute("msg",msg); 
				request.setAttribute("croll",cr);
				request.setAttribute("nroll",nr);
				request.setAttribute("name",n);
				request.setAttribute("phno",p);
				request.setAttribute("mail",m);
				//request.setAttribute("uname",u);
				//request.setAttribute("pass",pass);
				RequestDispatcher rd=request.getRequestDispatcher("updatehere.jsp");
				rd.forward(request,response);
			}
		}
		
		
	}

}
